
package java8.io;

import org.jooq.lambda.Unchecked;

import java.io.File;
import java.util.Arrays;


public class FileFilterGoodies {

    public static void main(String args[]) {
        System.out.println(0);
        listRecursive(new File("."));
    }

    /**
     * This method recursively lists all
     * .txt and .java files in a directory
     */
    private static void listRecursive(File dir) {
        Arrays.stream(dir.listFiles((f, n) ->
                     !n.startsWith(".")
                  &&
                     (f.isDirectory()
                  ||  n.endsWith(".txt")
                  ||  n.endsWith(".java"))
              ))
              .forEach(Unchecked.consumer((file) -> {
                  System.out.println(
                      file.getCanonicalPath()
                          .substring(
                              new File(".")
                                  .getCanonicalPath()
                                  .length()
                          ));

                      if (file.isDirectory()) {
                          listRecursive(file);
                      }
              }));
    }
}
